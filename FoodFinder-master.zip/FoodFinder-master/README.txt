Food Finder (Daemon Dash Project, UMD)

To start run this program, you must import data.csv into your local database. More information is as follows: 
	host = "localhost"
	user = "fooduser"
	password = "findyourfood"
	database = "foodfinder"
	table = "restaurants"
Visit the main.php link, choose the types of food you’re looking for, click submit, and now you should be able to visualize the map of where the certain foods are located and be able to click on the pop-up markers to get the address of where you want to eat (restaurant names were not available in the dataset). 


The Misadventures of Flap Jack Team Members: 
Nick Chen
Rajesh Nair
Jaya Chandar
Oscar Lomibao Jr.


Data source: 

https://www.kaggle.com/datafiniti/vegetarian-vegan-restaurants

http://stackoverflow.com/questions/3059044/google-maps-js-api-v3-simple-multiple-marker-example

http://www.w3schools.com/html/html5_geolocation.asp

